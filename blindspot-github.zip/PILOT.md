# Blindspot pilot playbook

## Offer
For teams selling an API or SDK: we try one first-run developer task from a clean environment, then deliver a reproducible report with the first blocker, evidence, and a proposed fix. Founding pilot price to test: $200 per completed run. This is a price hypothesis, not a claim of revenue.

## Delivery standard
- Customer supplies public docs URL, a sandbox key or test account, and the target first outcome. Never request production credentials or customer data.
- Record environment, timestamp, doc entry point, every command, observed output, and decision made.
- Mark each finding as reproduced, plausible, or needs confirmation. Do not present an AI prediction as actual user behavior.
- Send a one-page report within two working days: goal, completion state, first blocker, reproduction steps, evidence, fix, and confirmation request.
- Ask what the issue costs in support burden or lost activation and whether a repeat test after each release would be worth paying for.

## Initial research list (prospects, not customers)
1. Context.dev — web-data API; public quickstart and SDK path: https://www.context.dev/ and https://docs.context.dev/agent-quickstart
2. Orthogonal — unified API platform; quickstart and sandbox credits: https://www.orthogonal.com/
3. Kestrel AI — platform-engineering CLI, Python SDK and MCP server: https://usekestrel.ai/
4. Fragno / ReJot — integration framework with public quickstart: https://github.com/rejot-dev/fragno
5. Specific — isolated cloud projects through an API: https://www.ycombinator.com/companies/specific
These are product-fit hypotheses based on public descriptions. No one has agreed to a pilot.

## Outreach draft (review before sending)
Subject: I tried your first developer workflow

Hi [name], I’m building Blindspot to test the first mile of developer products. I’d like to take your docs from a clean machine to [specific first successful outcome], then send you the exact steps, any blocker, and one proposed fix. If that would be useful, could you share a sandbox account or key with restricted permissions? No production access needed. I can return a short report within two working days.

Krish

## Decision rule
Talk to ten teams. Seek three who will give a sandbox account or a specific first-run goal, and at least one who pays for a repeat run. If no one does, change the task or buyer before building an automated agent.

## Competitive reality
Meerkat and Prefigure offer broad simulated user tests. Armature tests whether coding agents select developer tools, and Quantstruct tests and improves product documentation. Blindspot's proposed distinction is a first-success developer journey with terminal-level evidence, but this needs real customer validation. The name Blindspot is already used by blindspot.ai and needs clearance or replacement before external branding investment.
